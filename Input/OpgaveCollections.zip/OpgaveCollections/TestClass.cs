﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OpgaveCollections
{
    class TestClass : VrachtSchip
    {
        public int AantalContainers { get; set; }
        public int test1;
        public int test2 = 1;
        public string test3 = "tester";
        public string test4 = "tester";
        public double test5 = 7;
        Containerschip testschip;
        public TestClass(string naam, double tonnage, double breedte, double lengte, double cargoWaarde, int aantalContainers) : base(naam, tonnage, breedte, lengte, cargoWaarde)
        {
            Naam = naam;
            Tonnage = tonnage;
            Breedte = breedte;
            Lengte = lengte;
            CargoWaarde = cargoWaarde;
            AantalContainers = aantalContainers;
        }
        public override string ToString()
        {
            return $"Naam: {Naam} \n Tonnage: {Tonnage} \n Breedte: {Breedte} \n Lengte: {Lengte} \n Cargo Waarde: {CargoWaarde} \n Aantal Containers: {AantalContainers}";
        }
    }
}
